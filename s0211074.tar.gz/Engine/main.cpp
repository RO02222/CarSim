#include <iostream>
#include <vector>

int main2() {

    return 0;
}
